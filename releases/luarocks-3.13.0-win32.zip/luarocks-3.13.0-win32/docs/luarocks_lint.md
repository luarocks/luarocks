# luarocks lint

Check syntax of a rockspec.

## Usage

`luarocks lint <rockspec>`

Checks syntax and format of a local rockspec.

## Example

```
luarocks lint my-rock-0.1.0-1.rockspec
```
