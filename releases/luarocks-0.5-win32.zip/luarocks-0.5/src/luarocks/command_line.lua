
program_version = "0.5"

--- Functions for command-line scripts.
module("luarocks.command_line", package.seeall)

local util = require("luarocks.util")
local config = require("luarocks.config")
local fs = require("luarocks.fs")

--- Display an error message and exit.
-- @param message string: The error message.
local function die(message)
   assert(type(message) == "string")

   local ok, err = pcall(util.run_scheduled_functions)
   if not ok then
      print("\nLuaRocks "..program_version.." internal bug (please report at luarocks-developers@lists.luaforge.net):\n"..err)
   end
   print("\nError: "..message)
   os.exit(1)
end

--- Main command-line processor.
-- Parses input arguments and calls the appropriate driver function
-- to execute the action requested on the command-line, forwarding
-- to it any additional arguments passed by the user.
-- Uses the global table "commands", which contains
-- the loaded modules representing commands.
-- @param ... string: Arguments given on the command-line.
function run_command(...)
   local args = {...}
   local cmdline_vars = {}
   for i = #args, 1, -1 do
      local arg = args[i]
      if arg:match("^[^-][^=]*=") then
         local var, val = arg:match("^([A-Z_][A-Z0-9_]*)=(.*)")
         if val then
            cmdline_vars[var] = val
            table.remove(args, i)
         else
            die("Invalid assignment: "..arg)
         end
      end
   end
   local nonflags = { util.parse_flags(unpack(args)) }
   local flags = table.remove(nonflags, 1)
   
   if flags["to"] then
      if flags["to"] == true then
         die("Argument error: use --to=<path>")
      end
      local root_dir = fs.absolute_name(flags["to"])
      config.root_dir = root_dir
      config.rocks_dir = root_dir.."/rocks/"
      config.scripts_dir = rawget(config, "scripts_dir") or root_dir.."/bin/"
   else
      local trees = config.rocks_trees
      for i = #trees, 1, -1 do
         local tree = trees[i]
         if fs.is_writable(tree) then
            config.root_dir = tree
            config.rocks_dir = tree.."/rocks/"
            config.scripts_dir = rawget(config, "scripts_dir") or tree.."/bin/"
            break
         end
      end
   end

   if flags["from"] then
      if flags["from"] == true then
         die("Argument error: use --from=<url>")
      end
      table.insert(config.rocks_servers, 1, flags["from"])
   end
   
   if flags["only-from"] then
      if flags["only-from"] == true then
         die("Argument error: use --only-from=<url>")
      end
      config.rocks_servers = { flags["only-from"] }
   end
   
   local command
   if flags["help"] or #nonflags == 0 then
      command = "help"
      args = nonflags
   elseif flags["version"] then
      print(program_name.." "..program_version)
      print(program_description)
      print()
      os.exit(0)
   else
      command = nonflags[1]
      for i, arg in ipairs(args) do
         if arg == command then
            table.remove(args, i)
            break
         end
      end
   end
   
   if command ~= "help" then
      for k, v in pairs(cmdline_vars) do
         config.variables[k] = v
      end
   end
   
   command = command:gsub("-", "_")
   if commands[command] then
      local xp, ok, err = xpcall(function() return commands[command].run(unpack(args)) end, function(err)
         die(debug.traceback("LuaRocks "..program_version
            .." bug (please report at luarocks-developers@lists.luaforge.net).\n"
            ..err, 2))
      end)
      if xp and (not ok) then
         die(err)
      end
   else
      die("Unknown command: "..command)
   end
   
   util.run_scheduled_functions()
end
