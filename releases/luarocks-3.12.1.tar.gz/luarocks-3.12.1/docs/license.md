# License

LuaRocks uses the MIT license. See the file
[COPYING](https://github.com/luarocks/luarocks/blob/master/COPYING) at the
root of the repository for the license text.
