return {
    build_dir = "build",
    source_dir = "src",
    include_dir = { "src", "types" },
    gen_target = "5.1",
}
