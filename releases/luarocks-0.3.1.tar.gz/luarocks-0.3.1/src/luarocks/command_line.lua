
--- Functions for command-line scripts.
module("luarocks.command_line", package.seeall)

local util = require("luarocks.util")

--- Display an error message and exit.
-- @param message string: The error message.
function die(message)
   assert(type(message) == "string")

   local ok, err = pcall(util.run_scheduled_functions)
   if not ok then
      print("LuaRocks bug (please report at luarocks-developers@lists.luaforge.net):\n"..err)
   end
   print('Error: '..message)
   os.exit(1)
end

--- Main command-line processor.
-- Parses input arguments and calls the appropriate driver function
-- to execute the action requested on the command-line, forwarding
-- to it any additional arguments passed by the user.
-- Uses the global table "commands", which contains
-- the loaded modules representing commands.
-- @param ... string: Arguments given on the command-line.
function run_command(...)
   local nonflags = { util.parse_flags(...) }
   local flags = table.remove(nonflags, 1)
   local args = {...}

   local cmdline_vars = {}
   while true do
      local set = -1
      local var,val
      for i, arg in ipairs(args) do
         if arg:match("=") then
            var,val = arg:match("^([A-Z_][A-Z0-9_]*)=(.*)")
            if val then
               set = i
               break
            else
               die("Invalid assignment: "..arg)
            end
         end
      end
      if set == -1 then
         break
      end
      local setflag = table.remove(args, set)
      cmdline_vars[var] = val
   end

   if flags["help"] or #args == 0 then
      command = "help"
      args = nonflags
      table.insert(args, 1, "help")
   elseif flags["version"] then
      print(program_name.." "..program_version)
      print(program_description)
      print()
      os.exit(0)
   else
      command = args[1]
   end
   table.remove(args, 1)
   
   if command ~= "help" then
      config = require("luarocks.config")
      for k, v in pairs(cmdline_vars) do
         config.variables[k] = v
      end
   end
   command = command:gsub("-", "_")
   if commands[command] then
      local pcall_ok, result, err = pcall(commands[command].run, unpack(args))
      if not pcall_ok then
         die("LuaRocks bug (please report at luarocks-developers@lists.luaforge.net):\n"..result)
      elseif err then
         die(err)
      end
   else
      die("Unknown command: "..command)
   end
   
   util.run_scheduled_functions()
end
