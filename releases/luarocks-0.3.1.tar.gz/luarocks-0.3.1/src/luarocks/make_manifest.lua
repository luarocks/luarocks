
--- Module implementing the luarocks-admin "make_manifest" command.
-- Compile a manifest file for a repository.
module("luarocks.make_manifest", package.seeall)

local fs = require("luarocks.fs")
local rep = require("luarocks.rep")
local search = require("luarocks.search")
local deps = require("luarocks.deps")
local config = require("luarocks.config")
local persist = require("luarocks.persist")
local fetch = require("luarocks.fetch")

help_summary = "Compile a manifest file for a repository."

help = [[
<argument>, if given, is a local repository pathname.
]]

--- Sort function for ordering rock identifiers in a manifest's
-- modules table. Rocks are ordered alphabetically by name, and then
-- by version which greater first.
-- @param a string: Version to compare.
-- @param b string: Version to compare.
-- @return boolean: The comparison result, according to the
-- rule outlined above.
local function sort_pkgs(a, b)
   assert(type(a) == "string")
   assert(type(b) == "string")

   local na, va = a:match("(.*)/(.*)$")
   local nb, vb = b:match("(.*)/(.*)$")
   
   return (na == nb) and deps.compare_versions(va, vb) or na < nb
end

--- Output a table listing items of a package.
-- @param itemsfn function: a function for obtaining items of a package.
-- pkg and version will be passed to it; it should return a table with
-- items as keys.
-- @param pkg string: package name
-- @param version string: package version
-- @param tbl table: the package matching table: keys should be item names
-- and values arrays of strings with packages names in "name/version" format.
local function store_package_items(itemsfn, pkg, version, tbl)
   assert(type(itemsfn) == "function")
   assert(type(pkg) == "string")
   assert(type(version) == "string")
   assert(type(tbl) == "table")

   local path = pkg.."/"..version
   local result = {}
   for item, _ in pairs(itemsfn(pkg, version)) do
      table.insert(result, item)
      if not tbl[item] then
         tbl[item] = {}
      end
      table.insert(tbl[item], path)
   end
   return result
end

--- Sort items of a package matching table by version number (higher versions first).
-- @param tbl table: the package matching table: keys should be strings
-- and values arrays of strings with packages names in "name/version" format.
local function sort_package_matching_table(tbl)
   assert(type(tbl) == "table")
   
   if next(tbl) then
      for item, pkgs in pairs(tbl) do
         if #pkgs > 1 then
            table.sort(pkgs, sort_pkgs)
            -- Remove duplicates from the sorted array.
            local prev = nil
            local i = 1
            while pkgs[i] do
               local curr = pkgs[i]
               if curr == prev then
                  table.remove(pkgs, i)
               else
                  prev = curr
                  i = i + 1
               end
            end
         end
      end
   end
end

local function save_manifest(repo, manifest)
   local filename = fs.make_path(repo, "manifest")
   return persist.save_from_table(filename, manifest)
end

--- Store search results in a manifest table.
-- @param results table: The search results as returned by search.disk_search.
-- @param manifest table: A manifest table (must contain repository, modules, commands tables).
local function store_results(results, manifest)
   assert(type(results) == "table")
   assert(type(manifest) == "table")

   for pkg, versions in pairs(results) do
      local pkgtable = manifest.repository[pkg] or {}
      for version, repos in pairs(versions) do
         local versiontable = {}
         for _, repo in ipairs(repos) do
            local repotable = {}
            repotable.arch = repo.arch
            if repo.arch == "installed" then
               repotable.modules = store_package_items(rep.package_modules, pkg, version, manifest.modules)
               repotable.commands = store_package_items(rep.package_commands, pkg, version, manifest.commands)
            end
            table.insert(versiontable, repotable)
         end
         pkgtable[version] = versiontable
      end
      manifest.repository[pkg] = pkgtable
   end
   sort_package_matching_table(manifest.modules)
   sort_package_matching_table(manifest.commands)
end

--- Load a manifest file from a local repository and add to the repository
-- information with regard to the given name and version.
-- A file called 'manifest' will be written in the root of the given
-- repository directory.
-- @param name string: Name of a package from the repository.
-- @param version string: Version of a package from the repository.
-- @param repo string or nil: Pathname of a local repository. If not given,
-- the default local repository configured as config.repo_dir is used.
-- @return boolean or (nil, string): True if manifest was generated,
-- or nil and an error message.
function update_manifest(name, version, repo)
   assert(type(name) == "string")
   assert(type(version) == "string")
   assert(type(repo) == "string" or not repo)
   repo = repo or config.repo_dir

   print("Updating manifest for "..repo)

   if not fs.exists(repo) then
      return make_manifest(repo)
   end
   local manifest, err = fetch.load_manifest(repo)
   if not manifest then
      print("Failed loading manifest. Attempting to rebuild...")
      local ok, err = make_manifest(repo)
      if not ok then
         return nil, err
      else
         return true
      end
   end

   results = {[name] = {[version] = {{arch = "installed", repo = repo}}}}
   
   store_results(results, manifest)
   return save_manifest(repo, manifest)
end

--- Scan a LuaRocks repository and output a manifest file.
-- A file called 'manifest' will be written in the root of the given
-- repository directory.
-- @param repo A local repository directory.
-- @return boolean or (nil, string): True if manifest was generated,
-- or nil and an error message.
function make_manifest(repo)
   assert(type(repo) == "string")

   if not fs.is_dir(repo) then
      return nil, "Cannot access repository at "..repo
   end

   local query = search.make_query("")
   query.exact_name = false
   query.arch = "any"
   local results = search.disk_search(repo, query)

   local manifest = { repository = {}, modules = {}, commands = {} }
   store_results(results, manifest)
   return save_manifest(repo, manifest)
end

--- Driver function for "make_manifest" command.
-- @param repo string or nil: Pathname of a local repository. If not given,
-- the default local repository configured as config.repo_dir is used.
-- @return boolean or (nil, string): True if manifest was generated,
-- or nil and an error message.
function run(repo)
   assert(type(repo) == "string" or not repo)
   repo = repo or config.repo_dir
   
   print("Making manifest for "..repo)
   
   return make_manifest(repo)
end
