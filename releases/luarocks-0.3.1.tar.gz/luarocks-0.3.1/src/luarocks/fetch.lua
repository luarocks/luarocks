
--- Functions related to fetching and loading local and remote files.
module("luarocks.fetch", package.seeall)

local fs = require("luarocks.fs")
local type_check = require("luarocks.type_check")
local path = require("luarocks.path")
local deps = require("luarocks.deps")
local persist = require("luarocks.persist")
local util = require("luarocks.util")

manifest_cache = {}

--- Fetch a local or remote file.
-- Make a remote or local URL/pathname local, fetching the file if necessary.
-- Other "fetch" and "load" functions use this function to obtain files.
-- If a local pathname is given, it is returned as a result.
-- @param url string: a local pathname or a remote URL.
-- @param filename string or nil: this function attempts to detect the
-- resulting local filename of the remote file as the basename of the URL;
-- if that is not correct (due to a redirection, for example), the local
-- filename can be given explicitly as this second argument.
-- @return string or (nil, string): the absolute local pathname for the
-- fetched file, or nil and a message in case of errors.
function fetch_url(url, filename)
   assert(type(url) == "string")
   assert(type(filename) == "string" or not filename)

   local protocol, pathname = fs.split_url(url)
   if protocol == "file" then
      return fs.absolute_name(pathname)
   elseif protocol == "http" or protocol == "ftp" or protocol == "https" then
      local ok = fs.download(url)
      if not ok then
         return nil, "Failed downloading "..url
      end
      return fs.make_path(fs.current_dir(), filename or fs.base_name(url))
   else
      return nil, "Unsupported protocol "..protocol
   end
end

--- For remote URLs, create a temporary directory and download URL inside it.
-- This temporary directory will be deleted on program termination.
-- For local URLs, just return the local pathname and its directory.
-- @param url string: URL to be downloaded
-- @param tmpname string: name pattern to use for avoiding conflicts
-- when creating temporary directory.
-- @param filename string or nil: local filename of URL to be downloaded,
-- in case it can't be inferred from the URL.
-- @return (string, string) or (nil, string): absolute local pathname of
-- the fetched file and temporary directory name; or nil and an error message.
local function fetch_url_at_temp_dir(url, tmpname, filename)
   assert(type(url) == "string")
   assert(type(tmpname) == "string")
   assert(type(filename) == "string" or not filename)
   filename = filename or fs.base_name(url)

   local protocol, pathname = fs.split_url(url)
   if protocol == "file" then
      if not fs.exists(pathname) then
         return nil, "Local file does not exist: "..pathname
      end
      return pathname, fs.dir_name(pathname)
   else
      local dir = fs.make_temp_dir(tmpname)
      if not dir then
         return nil, "Failed creating temporary directory."
      end
      util.schedule_function(fs.delete, dir)
      fs.change_dir(dir)
      local file, err = fetch_url(url, filename)
      if not file then
         return nil, "Error fetching file: "..err
      end
      fs.pop_dir()
      return file, dir
   end
end

--- Obtain a rock and unpack it.
-- If a directory is not given, a temporary directory will be created,
-- which will be deleted on program termination.
-- @param rock_file string: URL or filename of the rock.
-- @param dest string or nil: if given, directory will be used as
-- a permanent destination.
-- @return string or (nil, string): the directory containing the contents
-- of the unpacked rock.
function fetch_and_unpack_rock(rock_file, dest)
   assert(type(rock_file) == "string")
   assert(type(dest) == "string" or not dest)

   local name = fs.base_name(rock_file):match("(.*)%.[^.]*%.rock")
   
   local rock_file, err = fetch_url_at_temp_dir(rock_file,"luarocks-rock-"..name)
   if not rock_file then
      return nil, "Could not fetch rock file: " .. err
   end

   rock_file = fs.absolute_name(rock_file)
   local dir
   if dest then
      dir = dest
      fs.make_dir(dir)
   else
      dir = fs.make_temp_dir(name)
   end
   if not dir or not fs.exists(dir) then
      return nil, "Error creating directory for unpacking rock."
   end
   if not dest then
      util.schedule_function(fs.delete, dir)
   end
   fs.change_dir(dir)
   fs.unzip(rock_file)
   fs.pop_dir()
   return dir
end

--- Load a rockspec into a table.
-- All functions that use rockspec tables assume they were obtained
-- through this function, which performs some validation and
-- postprocessing of the rockspec contents.
-- @param filename string: Local or remote filename of a rockspec.
-- @return table or (nil, string): A table representing the rockspec
-- or nil followed by an error message.
function load_rockspec(filename)
   assert(type(filename) == "string")

   local name = fs.base_name(filename):match("(.*)%.rockspec")
   
   local filename, err = fetch_url_at_temp_dir(filename,"luarocks-rockspec-"..name)
   if not filename then
      return nil, err
   end

   local rockspec, err = persist.load_into_table(filename)
   if not rockspec then
      return nil, "Could not load rockspec file "..filename.." ("..err..")"
   end
   local ok, err = type_check.type_check_rockspec(rockspec)
   if not ok then
      return nil, filename..": "..err
   end   
   local basename = fs.base_name(filename)
   rockspec.name = basename:match("(.*)-[^-]*-[0-9]*")
   if not rockspec.name then
      return nil, "Expected filename in format 'name-version-revision.rockspec'."
   end
   local name_version = rockspec.package:lower() .. "-" .. rockspec.version
   if basename ~= name_version .. ".rockspec" then
      return nil, "Inconsistency between rockspec filename ("..basename..") and its contents ("..name_version..".rockspec)."
   end

   rockspec.local_filename = filename
   rockspec.source.file = rockspec.source.file
                       or fs.base_name(rockspec.source.url)
   local file_without_extension = rockspec.source.file:match("(.-)%.[a-z.]*$")
   rockspec.source.dir = rockspec.source.dir
                      or rockspec.source.cvs_module
                      or file_without_extension
                      or rockspec.source.file
   if rockspec.dependencies then
      for i = 1, #rockspec.dependencies do
         local parsed = deps.parse_dep(rockspec.dependencies[i])
         if not parsed then
            return nil, "Parse error processing dependency '"..rockspec.dependencies[i].."'"
         end
         rockspec.dependencies[i] = parsed
      end
   else
      rockspec.dependencies = {}
   end
   local ok, err = path.configure_paths(rockspec)
   if err then
      return nil, "Error verifying paths: "..err
   end

   return rockspec
end

--- Download sources (via HTTP, FTP, CVS) for building a rock.
-- @param rockspec table: The rockspec table
-- @param extract boolean: Whether to extract the sources from
-- the fetched source tarball or not.
-- @return (string, string) or (nil, string): The absolute pathname of
-- the fetched source tarball and the temporary directory created to
-- store it; or nil and an error message.
function fetch_sources(rockspec, extract)
   assert(type(rockspec) == "table")
   assert(type(extract) == "boolean")

   local name_version = rockspec.name .. "-" .. rockspec.version
   local protocol, pathname = fs.split_url(rockspec.source.url)
   if protocol == "cvs" then
      local module = rockspec.source.cvs_module or fs.base_name(rockspec.source.url)
      local command = {"cvs", "-d"..pathname, "export", module}
      if rockspec.source.cvs_tag then
         table.insert(command, 4, "-r")
         table.insert(command, 5, rockspec.source.cvs_tag)
      end
      local dir = fs.make_temp_dir(name_version)
      if not dir then
         return nil, "Failed creating temporary directory."
      end
      util.schedule_function(fs.delete, dir)
      fs.change_dir(dir)
      if not fs.execute(unpack(command)) then
         return nil, "Failed fetching files from CVS."
      end
      fs.pop_dir()
      return module, dir
   else
      local url = rockspec.source.url
      local name = rockspec.name.."-"..rockspec.version
      local filename = rockspec.source.name
      local source_file, dir = fetch_url_at_temp_dir(url, "luarocks-source-"..name)
      if not source_file then
         return nil, dir
      end
      if extract then
         fs.change_dir(dir)
         fs.unpack_archive(rockspec.source.file)
         fs.pop_dir()
      end
      return source_file, dir
   end
end

--- Load a local or remote manifest describing a repository.
-- All functions that use manifest tables assume they were obtained
-- through this function.
-- @param repo_url string: URL or pathname for the repository.
-- @return table or (nil, string): A table representing the manifest,
-- or nil followed by an error message.
function load_manifest(repo_url)
   assert(type(repo_url) == "string")
   
   if manifest_cache[repo_url] then
      return manifest_cache[repo_url]
   end

   local protocol, pathname = fs.split_url(repo_url)
   if protocol == "file" then
      manifest = persist.load_into_table(fs.make_path(pathname, "manifest"))
   else
      local url = fs.make_path(repo_url, "manifest")
      local name = repo_url:gsub("[/:]","_")
      local file, dir = fetch_url_at_temp_dir(url, "luarocks-manifest-"..name)
      if not file then
         return nil, "Failed fetching manifest for "..repo_url
      end
      fs.change_dir(dir)
      manifest = persist.load_into_table(file)
      fs.pop_dir()
   end
   if not manifest then
      return nil, "Failed loading manifest for "..repo_url
   end
   local ok, err = type_check.type_check_manifest(manifest)
   if not ok then
      return nil, err
   end
   
   manifest_cache[repo_url] = manifest
   return manifest
end
