
--- Utility module for loading files into tables.
-- Implemented separately to avoid interdependencies,
-- as it is used in the bootstrapping stage of config.
module("luarocks.load_table", package.seeall)

--- Load a Lua file containing assignments, storing them in a table.
-- The global environment is not propagated to the loaded file.
-- @param filename string: the name of the file.
-- @param tbl table or nil: if given, this table is used to store
-- loaded values.
-- @return table or (nil, string): a table with the file's assignments
-- as fields, or nil and a message in case of errors.
function load_into_table(filename, tbl)
   assert(type(filename) == "string")
   assert(type(tbl) == "table" or not tbl)

   local chunk, err = loadfile(filename)
   if not chunk then
      return nil, err
   end
   local result = {}
   if tbl then result = tbl end
   setfenv(chunk, result)
   chunk()
   return result
end
