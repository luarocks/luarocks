#!/bin/bash

if [ -e ./run_tests.sh ]
then
   cd ../src
elif [ -d src ]
then
   cd src
elif ! [ -d luarocks ]
then
   echo "Go to the src directory and run this."
   exit 1
fi

if [ ! -d ../rocks ]
then
   echo "Downloading entire rocks repository for tests"
   cd ..
   wget -r -nH -np -R"index.*" http://luarocks.luaforge.net/rocks/
   cd src
fi

rocks=(
   `ls ../rocks/*.rockspec`
   `ls ../rocks/*.src.rock`
   `ls ../rocks-cvs/*.rockspec`
)

bin/luarocks-admin make-manifest ../rocks || exit 1

[ "$1" ] && rocks=("$1")

for rock in "${rocks[@]}"
do
   base=`basename $rock`
   baserockspec=`basename $rock .rockspec`
   basesrcrock=`basename $rock .src.rock`
   if [ "$base" != "$baserockspec" ]
   then
      base=$baserockspec
      name=`echo $base | sed 's/\(.*\)-[^-]*-[^-]*$/\1/'`
      version=`echo $base | sed 's/.*-\([^-]*-[^-]*\)$/\1/'`
      bin/luarocks pack $rock || exit 1
      bin/luarocks build $base.src.rock || exit 1
      rm $base.src.rock || exit 1
   else
      base=$basesrcrock
      name=`echo $base | sed 's/\(.*\)-[^-]*-[^-]*$/\1/'`
      version=`echo $base | sed 's/.*-\([^-]*-[^-]*\)$/\1/'`
      bin/luarocks build $rock || exit 1
   fi
   bin/luarocks pack $name $version || exit 1
   bin/luarocks install $base.*.rock || exit 1
   rm $base.*.rock || exit 1
   bin/luarocks list $name | grep $version || exit 1
   bin/luarocks remove $name $version
   # TODO: differentiate between error and dependency block.
done

if bin/luarocks install nonexistant | grep "No results"
then echo "OK, got expected error."
else exit 1
fi

../test/test_deps.lua || exit 1
../test/test_require.lua || exit 1
