
--- Module implementing the LuaRocks "unpack" command.
-- Unpack the contents of a rock.
module("luarocks.unpack", package.seeall)

local fetch = require("luarocks.fetch")
local fs = require("luarocks.fs")
local util = require("luarocks.util")

help_summary = "Unpack the contents of a rock."
help_arguments = "{<rock>|<name> [<version>]}"
help = [[
Unpacks the contents of a source rock in a newly created directory.
Argument may be a rock file, or the name of a rock in a remote repository.
In the latter case, the app version may be given as a second argument.
]]

local function unpack_rock(rock_file)
   assert(type(rock_file) == "string")
   
   if not rock_file:match(".rock$") then
      return nil, "File "..rock_file.." does not seem to be a rock."
   end
   
   rock_file = fs.absolute_name(rock_file)
   local dir_name = fs.base_name(rock_file):gsub("%.[^.]+%.rock", "")
   if (fs.exists(dir_name)) then
      return nil, "Directory "..dir_name.." already exists."
   end
   
   fs.make_dir(dir_name)
   local rollback = util.schedule_function(fs.delete, dir_name)
   
   local ok, err = fetch.fetch_and_unpack_rock(rock_file, dir_name)
   if not ok then
      return nil, "Failed unzipping rock "..rock_file
   end

   fs.change_dir(dir_name)

   local rockspec_file = dir_name..".rockspec"
   local rockspec = fetch.load_rockspec(rockspec_file)
   if rockspec.source.file then
      local ok, err = fs.unpack_archive(rockspec.source.file)
      if not ok then
         return nil, err
      end
   end
   if rockspec.source.dir ~= "." then
      local ok = fs.copy(rockspec_file, rockspec.source.dir)
      if not ok then
         return nil, "Failed copying unpacked rockspec into unpacked source directory."
      end
   end

   print()   
   print("Done. You may now enter directory ")
   print(fs.make_path(dir_name, rockspec.source.dir))
   print("and type 'luarocks make' to build.")
   util.remove_scheduled_function(rollback)
   return true
end

local function find_and_unpack_rock(name, version)
   local search = require("luarocks.search")
   local query = search.make_query(name, version)
   query.arch = "src"
   local results1, err = search.find_suitable_rock(query)
   if type(results1) == "string" then
      return unpack_rock(results1)
   elseif type(results1) == "table" and next(results1) then
      print("Could not determine which rock to unpack.")
      print()
      print("Search results:")
      print("---------------")
      search.print_results(results1)
      return nil, "Please narrow your query."
   else
      return nil, "Could not find a rock named "..name.."."
   end
   return true
end

--- Driver function for the "unpack" command.
-- @param arg string:  may be a rock filename, for unpacking a 
-- rock file or the name of a rock to be fetched and unpacked.
-- @param version string or nil: if the name of a package is given, a
-- version may also be passed.
-- @return boolean or (nil, string): true if successful or nil followed
-- by an error message.
function run(arg, version)
   assert(type(version) == "string" or not version)
   if type(arg) ~= "string" then
      return nil, "Argument missing, see help."
   end

   if arg:match(".*%.rock") then
      return unpack_rock(arg)
   else
      return find_and_unpack_rock(arg, version)
   end
end
