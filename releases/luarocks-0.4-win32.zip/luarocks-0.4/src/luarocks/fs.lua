
local rawset = rawset

--- Proxy module for filesystem and platform abstractions.
-- All code using "fs" code should require "luarocks.fs",
-- and not the various platform-specific implementations.
-- However, see the documentation of the implementation
-- for the API reference.
module("luarocks.fs", package.seeall)

local config = require("luarocks.config")

local fs_impl = nil
for _, platform in pairs(config.platforms) do
   fs_impl = require("luarocks.fs_"..platform)
   if fs_impl then
      break
   end
end

local fs_mt = {
   __index = function(t, k)
      local impl = fs_impl[k]
      if impl then
         rawset(t, k, impl)
      end
      return impl
   end
}

setmetatable(luarocks.fs, fs_mt)
