return {
   binaryheap = "0.4-1", -- dependency for copas
   bit32 = "5.3.5.1-1", -- dependency for luaposix on Lua 5.1
   cluacov = "0.1.2-1",
   copas = "3.0.0-2",
   cprint = "0.2-1",
   dkjson = "2.6-1",
   lpeg = "1.0.0-1",
   luacov = "0.15.0-1",
   luafilesystem = "1.8.0-1",
   luafilesystem_old = "1.6.3-2",
   luaposix = "35.1-1",
   luasocket = "3.0.0-1",
   luasec = "1.3.2-1",
   lxsh = "0.8.6-2",
   timerwheel = "0.2.0-2", -- dependency for copas
}
