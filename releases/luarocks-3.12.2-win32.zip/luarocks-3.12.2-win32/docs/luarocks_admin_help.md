# luarocks-admin help

Help on commands.

## Usage

`luarocks-admin help [<command>]`

`<command>` is the command to show help for. If no argument is given, a list
of supported commands, with summaries, is shown.

## Example

```
luarocks-admin help make-manifest
```

