# Credits

# Institutional Sponsors

While developed by an open source community, LuaRocks has been supported in
various forms by a number of organizations over the years and we thank every
one of them:

* [CNPq](http://www.cnpq.br)
* [Fábrica Digital](https://www.fabricadigital.com.br/)
* [FINEP](http://www.finep.gov.br/)
* [IMPA](https://impa.br/)
* [LabLua](http://www.lua.inf.puc-rio.br/)
* [itch.io](https://itch.io/)
* [Kong](http://getkong.org/)

# Developers

LuaRocks is a collective project, a product of [many
hands](https://github.com/luarocks/luarocks/graphs/contributors). The
implementation is led by [Hisham Muhammad](http://hisham.hm), but see the [Git
history](https://github.com/luarocks/luarocks/commits/master) for
detailed credits.

