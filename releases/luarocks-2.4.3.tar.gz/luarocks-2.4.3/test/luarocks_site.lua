-- Config file of LuaRocks site for tests
upload = {
   server = "http://localhost:8080",
   tool_version = "1.0.0",
   api_version = "1",
}