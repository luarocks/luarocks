#!/bin/bash

if [ -e ./run_tests.sh ]
then
   cd ../src
elif [ -d src ]
then
   cd src
elif ! [ -d luarocks ]
then
   echo "Go to the src directory and run this."
   exit 1
fi

if [ ! -d ../rocks ]
then
   echo "Downloading entire rocks repository for tests"
   cd ..
   wget -r -nH -np -R"index.*" http://luarocks.luaforge.net/rocks/
   cd src
fi

rocks=(
   `ls ../rocks/*.rockspec`
)

bin/luarocks-admin make-manifest ../rocks || exit 1

for rock in "${rocks[@]}"
do
   base=`basename $rock .rockspec`
   bin/luarocks pack $rock || exit 1
   bin/luarocks build $base.src.rock || exit 1
   bin/luarocks install $base.src.rock || exit 1
   bin/luarocks pack `echo $base | sed 's/\(.*\)-[^-]*-[^-]*$/\1/'` `echo $base | sed 's/.*-\([^-]*-[^-]*\)$/\1/'` || exit 1
   rm $base.src.rock || exit 1
   bin/luarocks install $base.*.rock || exit 1
   rm $base.*.rock || exit 1
done

if bin/luarocks install nonexistant | grep "No results found"
then echo "OK, got expected error."
else exit 1
fi

../test/test_deps.lua || exit 1
../test/test_require.lua || exit 1
