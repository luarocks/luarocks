
local rawset = rawset

--- Configuration for LuaRocks.
-- Tries to load the user's configuration file and
-- defines defaults for unset values. See the
-- <a href="http://luarocks.org/en/Config_file_format">config
-- file format documentation</a> for details.
module("luarocks.config", package.seeall)

local persist = require("luarocks.persist")

-- TODO: proper OS detection, etc.
-- here is most likely not the proper place for it
-- but it works for now.
local detected = {}
local system,proc

-- Use the unix way to identify the system, even on windows.
system = io.popen("uname -s"):read("*l")
proc = io.popen("uname -m"):read("*l")
if proc:match("i[%d]86") then
   proc = "x86"
elseif proc:match("Power Macintosh") then
   proc = "powerpc"
end

if system and system == "Darwin" then
   detected.unix = true
   detected.macosx = true
end
if system and system == "Linux" then
   detected.unix = true
   detected.linux = true
end
if system and system:match("^CYGWIN") then
   detected.unix = true
   detected.cygwin = true
end
if system and system:match("^Windows") then
   detected.windows = true
end

LUAROCKS_CONFIG = LUAROCKS_CONFIG or os.getenv("LUAROCKS_CONFIG")
if detected.windows then
   appdata = os.getenv("APPDATA") or "c:"
   home_config = LUAROCKS_CONFIG or appdata.."/luarocks/config.lua"
else
   home = os.getenv("HOME") or ""
   home_config = LUAROCKS_CONFIG or home.."/.luarocks/config.lua"
end

variables = {}

local config, err = persist.load_into_table(home_config, luarocks.config)

defaults = {
   arch = "unknown",
   lib_extension = "unknown",
   obj_extension = "unknown",
   repositories = {
      "http://luarocks.luaforge.net/rocks"
   },
   lua_extension = "lua",
   lua_interpreter = LUA_INTERPRETER or "lua",
   variables = {}
}

if detected.windows then
   defaults.lib_extension = "dll"
   defaults.obj_extension = "obj"
   local rootdir = root_dir or home_config:match("(.*)/") or appdata.."/luarocks"
   defaults.root_dir = rootdir
   defaults.repo_dir = rootdir.."/rocks/"
   defaults.scripts_dir = rootdir.."/bin/"
   defaults.external_deps_dirs = { "c:/external/" }
   defaults.variables.LUA_BINDIR = LUA_BINDIR:gsub("\\", "/") or "c:/lua5.1/bin"
   defaults.variables.LUA_INCDIR = LUA_INCDIR:gsub("\\", "/") or "c:/lua5.1/include"
   defaults.variables.LUA_LIBDIR = LUA_LIBDIR:gsub("\\", "/") or "c:/lua5.1/lib"
   defaults.arch = "win32-"..proc
   defaults.platforms = {"win32", "windows" }
   defaults.cmake_generator = "MinGW Makefiles"
   -- TODO: Split windows flavors between mingw and msvc
   defaults.make = "make"
   -- defaults.makefile = "Makefile"
   -- defaults.make = "nmake"
   -- defaults.makefile = "Makefile.win"
end

if detected.unix then
   defaults.lib_extension = "so"
   defaults.obj_extension = "o"
   local rootdir = root_dir or home_config:match("(.*)/") or home.."/luarocks"
   defaults.root_dir = rootdir
   defaults.repo_dir = rootdir.."/rocks/"
   defaults.scripts_dir = rootdir.."/bin/"
   defaults.external_deps_dirs = { "/usr/local", "/usr" }
   defaults.variables.LUA_BINDIR = LUA_BINDIR or "/usr/local/bin"
   defaults.variables.LUA_INCDIR = LUA_INCDIR or "/usr/local/include"
   defaults.variables.LUA_LIBDIR = LUA_LIBDIR or "/usr/local/lib"
   defaults.cmake_generator = "Unix Makefiles"
   defaults.make = "make"
end

if detected.cygwin then
   defaults.lib_extension = "dll"
   defaults.arch = "cygwin-"..proc
   defaults.platforms = {"unix", "cygwin"}
   defaults.cmake_generator = "Unix Makefiles"
end

if detected.macosx then
   defaults.arch = "macosx-"..proc
   defaults.platforms = {"unix", "macosx"}
   defaults.variables.CC = "export MACOSX_DEPLOYMENT_TARGET=10.3; gcc"
   defaults.variables.CFLAGS = ""
   defaults.variables.LIBFLAG = "-bundle -undefined dynamic_lookup -all_load"
end

if detected.linux then
   defaults.arch = "linux-"..proc
   defaults.platforms = {"unix", "linux"}
   defaults.variables.CC = "gcc"
   defaults.variables.CFLAGS = ""
   defaults.variables.LIBFLAG = "-shared"
end

local config_mt = {
   __index = function(t, k)
      local default = defaults[k]
      if default then
         rawset(t, k, default)
      end
      return default
   end
}

setmetatable(luarocks.config, config_mt)
