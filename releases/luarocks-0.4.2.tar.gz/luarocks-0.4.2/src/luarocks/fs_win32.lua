--- Windows implementation of filesystem and platform abstractions.
-- Download http://unxutils.sourceforge.net/ for Windows GNU utilities
-- used by this module.
module("luarocks.fs_win32", package.seeall)

local config = require("luarocks.config")

local dir_stack = {}

dir_separator = "/"

--- Quote argument for shell processing. Fixes paths on windows.
-- Adds single quotes and escapes.
-- @param arg string: Unquoted argument.
-- @return string: Quoted argument.
local function Q(arg)
   assert(type(arg) == "string")
   -- Quote DIR for Windows
    if arg:match("^[\.a-zA-Z]?:?[\\/]")  then
        return '"' .. arg:gsub("/", "\\"):gsub('"', '\\"') .. '"'
    end
    -- URLs and anything else
   return '"' .. arg:gsub('"', '\\"') .. '"'
end

--- Obtain current directory.
-- Uses the module's internal dir stack.
-- @return string: the absolute path of the current directory.
function current_dir()
   current = io.popen("pwd"):read("*l")
   for _, dir in ipairs(dir_stack) do
      current = absolute_name(dir, current)
   end
   return current
end

--- Run the given command.
-- The command is executed in the current directory in the dir stack.
-- @param cmd string: No quoting/escaping is applied to the command.
-- @return boolean: true if command succeeds (status code 0), false
-- otherwise.
local function execute_string(cmd)
   --print("cd " .. Q(current_dir()) .. " & " .. cmd)
   if os.execute("cd " .. Q(current_dir()) .. " & " .. cmd) == 0 then
      return true
   else
      return false
   end
end

--- Run the given command, quoting its arguments.
-- The command is executed in the current directory in the dir stack.
-- @param command string: The command to be executed. No quoting/escaping
-- is applied.
-- @param ... Strings containing additional arguments, which are quoted.
-- @return boolean: true if command succeeds (status code 0), false
-- otherwise.
function execute(command, ...)
   assert(type(command) == "string")
   
   for _, arg in ipairs({...}) do
      assert(type(arg) == "string")
      command = command .. " " .. Q(arg)
   end
   return execute_string(command)
end

--- Change the current directory.
-- Uses the module's internal dir stack. This does not have exact
-- semantics of chdir, as it does not handle errors the same way,
-- but works well for our purposes for now.
-- @param dir string: The directory to switch to.
function change_dir(dir)
   assert(type(dir) == "string")
   table.insert(dir_stack, dir)
end

--- Change directory to root.
-- Allows leaving a directory (e.g. for deleting it) in
-- a crossplatform way.
function change_dir_to_root()
   table.insert(dir_stack, "/")
end

--- Change working directory to the previous in the dir stack.
function pop_dir()
   table.remove(dir_stack)
end

--- Create a directory if it does not already exist.
-- If any of the higher levels in the path name does not exist
-- too, they are created as well.
-- @param dir string: pathname of directory to create.
-- @return boolean: true on success, false on failure.
function make_dir(dir)
   assert(dir)
   execute("mkdir "..Q(dir).." 1> NUL 2> NUL")
   return 1
end

--- Remove a directory if it is empty.
-- Does not return errors (for example, if directory is not empty or
-- if already does not exist)
-- @param dir string: pathname of directory to remove.
function remove_dir_if_empty(dir)
   assert(dir)
   execute_string("rmdir "..Q(dir).." 1> NUL 2> NUL")
end

--- Move a file from one location to another
-- @param src string: Pathname of source
-- @param dest string: Pathname of destination
-- @return boolean: true on success, false on failure.
function move(src, dest)
   assert(src and dest)
   return execute("mv", src, dest)
end

--- Copy a file.
-- @param src string: Pathname of source
-- @param dest string: Pathname of destination
-- @return boolean or (boolean, string): true on success, false on failure,
-- plus an error message.
function copy(src, dest)
   assert(src and dest)
   if execute("cp", src, dest) then
      return true
   else
      return false, "Failed copying "..src.." to "..dest
   end
end

--- Delete a file or a directory and all its contents.
-- For safety, this only accepts absolute paths.
-- @param arg string: Pathname of source
-- @return boolean: true on success, false on failure.
function delete(arg)
   assert(arg)
   assert(arg:match("^[\a-zA-Z]?:?[\\/]"))
   return execute_string("rm -rf " .. Q(arg) .. " 1> NUL 2> NUL")
end

--- List the contents of a directory. 
-- @param at string or nil: directory to list (will be the current
-- directory if none is given).
-- @return table: an array of strings with the filenames representing
-- the contents of a directory.
function dir(at)
   assert(type(at) == "string" or not at)
   if not at then
      at = current_dir()
   end
   local result = {}
   if not is_dir(at) then
      return {}
   end
   for file in io.popen("cd "..Q(at).." & ls"):lines() do
      table.insert(result, file)
   end
   return result
end

--- Recursively scan the contents of a directory. 
-- @param at string or nil: directory to scan (will be the current
-- directory if none is given).
-- @return table: an array of strings with the filenames representing
-- the contents of a directory. Paths are returned with forward slashes.
function find(at)
   assert(type(at) == "string" or not at)
   if not at then
      at = current_dir()
   end
   local result = {}
   if not is_dir(at) then
      return {}
   end
   for file in io.popen("cd "..Q(at).." & find 2> NUL"):lines() do
      -- windows find is a bit different
      if file:sub(1,2)==".\\" then file=file:sub(3) end
      if file ~= "." then
         table.insert(result, (file:gsub("\\", "/")))
      end
   end
   return result
end

--- Compress files in a .zip archive.
-- @param zipfile string: pathname of .zip archive to be created.
-- @param ... Filenames to be stored in the archive are given as
-- additional arguments.
-- @return boolean: true on success, false on failure.
function zip(zipfile, ...)
   return execute("zip -r", zipfile, ...)
end

--- Uncompress files from a .zip archive.
-- @param zipfile string: pathname of .zip archive to be extracted.
-- @return boolean: true on success, false on failure.
function unzip(zipfile)
   assert(zipfile)
   return execute("unzip", zipfile)
end

--- Test for existance of a file.
-- @param file string: filename to test
-- @return boolean: true if file exists, false otherwise.
function exists(file)
   assert(file)
   return execute("test -e", file)
end

--- Test is pathname is a directory.
-- @param file string: pathname to test
-- @return boolean: true if it is a directory, false otherwise.
function is_dir(file)
   assert(file)
   return execute("test -d", file)
end

--- Download a remote file.
-- @param url string: URL to be fetched.
-- @param filename string or nil: this function attempts to detect the
-- resulting local filename of the remote file as the basename of the URL;
-- if that is not correct (due to a redirection, for example), the local
-- filename can be given explicitly as this second argument.
-- @return boolean: true on success, false on failure.
function download(url, filename)
   assert(type(url) == "string")
   assert(type(filename) == "string" or not filename)

   if filename then   
      return execute("wget --quiet --continue --output-document ", filename, url)
   else
      return execute("wget --quiet --continue ", url)
   end
end

--- Strip the path off a path+filename.
-- @param pathname string: A path+name, such as "/a/b/c".
-- @return string: The filename without its path, such as "c".
function base_name(pathname)
   assert(type(pathname) == "string")

   local base = pathname:match(".*[/\\]([^/\\]*)")
   return base or pathname
end

--- Strip the name off a path+filename.
-- @param pathname string: A path+name, such as "/a/b/c".
-- @return string: The filename without its path, such as "/a/b/".
-- For entries such as "/a/b/", "/a/" is returned. If there are
-- no directory separators in input, "" is returned.
function dir_name(pathname)
   assert(type(pathname) == "string")

   local dir = pathname:gsub("/*$", ""):match("(.*/)[^/]*")
   return dir or ""
end

--- Create a temporary directory.
-- @param name string: name pattern to use for avoiding conflicts
-- when creating temporary directory.
-- @return string or nil: name of temporary directory or nil on failure.
function make_temp_dir(name)
   assert(type(name) == "string")

   local temp_dir = (os.getenv("TMP") or "/tmp") .."/".. name
   if make_dir(temp_dir) then
      return temp_dir
   else
      return nil
   end
end

--- Apply a patch.
-- @param patchname string: The filename of the patch.
function patch(patchname)
   return execute("patch -p1 -i ", patchname)
end

--- Strip the last extension of a filename.
-- Example: "foo.tar.gz" becomes "foo.tar".
-- If filename has no dots, returns it unchanged.
-- @param filename string: The file name to strip.
-- @return string: The stripped name.
local function strip_extension(filename)
   assert(type(filename) == "string")

   return (filename:gsub("%.[^.]+$", "")) or filename
end

--- Unpack an archive.
-- Extract the contents of an archive, detecting its format by
-- filename extension.
-- @param archive string: Filename of archive.
-- @return boolean or (boolean, string): true on success, false and an error message on failure.
function unpack_archive(archive)
   assert(type(archive) == "string")
   
   local ok
   if archive:match("%.tar%.gz$") then
      ok = execute("gunzip ", archive)
      if ok then
         ok = execute("tar -xf ", strip_extension(archive))
      end
   elseif archive:match("%.tgz$") then
      ok = execute("gunzip ", archive)
      if ok then
         ok = execute("tar -xf ", strip_extension(archive)..".tar")
      end
   elseif archive:match("%.tar%.bz2$") then
      ok = execute("bunzip2 ", archive)
      if ok then
         ok = execute("tar -xf ", strip_extension(archive))
      end
   elseif archive:match("%.zip$") then
      ok = execute("unzip ", archive)
   else
      local ext = archive:match(".*(%..*)")
      return false, "Unrecognized filename extension "..(ext or "")
   end
   if not ok then
      return false, "Failed extracting "..archive
   end
   return true
end

--- Check the MD5 checksum for a file.
-- @param file string: The file to be checked.
-- @param md5sum string: The string with the expected MD5 checksum.
-- @return boolean: true if the MD5 checksum for 'file' equals 'md5sum', false if not
-- or if it could not perform the check for any reason.
function check_md5(file, md5sum)
   file = absolute_name(file)
   local computed = io.popen("md5sum "..file):read("*l")
   if not computed then
      return false
   end
   if computed:match("^"..md5sum) then
      return true
   else
      return false
   end
end

--- Return an absolute pathname from a potentially relative one.
-- @param pathname string: pathname to convert.
-- @param relative_to string or nil: path to prepend when making
-- pathname absolute, or the current dir in the dir stack if
-- not given.
-- @return string: The pathname converted to absolute.
function absolute_name(pathname, relative_to)
   assert(type(pathname) == "string")
   assert(type(relative_to) == "string" or not relative_to)

   relative_to = relative_to or current_dir()
   if pathname:match("^[\.a-zA-Z]?:?[\\/]") then
      return pathname
   else
      return relative_to .. "/" .. pathname
   end
end

--- Describe a path in a cross-platform way.
-- Use this function to avoid platform-specific directory
-- separators in other modules. If the first item contains a 
-- protocol descriptor (e.g. "http:"), paths are always constituted
-- with forward slashes.
-- @param ... strings representing directories
-- @return string: a string with a platform-specific representation
-- of the path.
function make_path(...)
   local items = {...}
   i = 1
   while items[i] do
      if items[i] == "" then
         table.remove(items, i)
      else
         i = i + 1
      end
   end
   return table.concat(items, "/")
end

--- Convert a relative path to an absolute one.
-- If a relative path is given, make it absolute relative to
-- the current directory. If an absolute path is given, don't touch it.
-- @path string: A relative or absolute path.
-- @return string: An absolute path.
function absolute_path(path)
   assert(type(path) == "string")
   
   if path:match("^[a-zA-Z]:") then
      return path
   else
      return make_path(current_dir(), path)
   end
end

--- Split protocol and path from an URL or local pathname.
-- URLs should be in the "protocol://path" format.
-- For local pathnames, "file" is returned as the protocol.
-- @param url string: an URL or a local pathname.
-- @return string, string: the protocol, and the pathname without the protocol.
function split_url(url)
   assert(type(url) == "string")
   
   local protocol, pathname = url:match("^([^:]*)://(.*)")
   if not protocol then
      protocol = "file"
      pathname = url
   end
   if protocol == "file" then
      pathname = absolute_path(pathname)
   end
   return protocol, pathname
end

--- Create a wrapper to make a script executable from the command-line.
-- @param file string: Pathname of script to be made executable.
-- @param dest string: Directory where to put the wrapper.
-- @return boolean or (nil, string): True if succeeded, or nil and
-- an error message.
function wrap_script(file, dest)
   assert(type(file) == "string")
   assert(type(dest) == "string")

   local base = base_name(file)
   local wrapname = dest.."/"..base..".bat"
   local wrapper = io.open(wrapname, "w")
   if not wrapper then
      return nil, "Could not open "..wrapname.." for writing."
   end
   wrapper:write("@echo off\n")
   wrapper:write("setlocal\n")
   wrapper:write("set LUAROCKS_CONFIG="..config.home_config.."\n")
   wrapper:write('set LUA_PATH='..package.path..";%LUA_PATH%\n")
   wrapper:write('set LUA_CPATH='..package.cpath..";%LUA_CPATH%\n")
   wrapper:write('"'..make_path(config.get_variable("LUA_BINDIR"), config.lua_interpreter)..'" -lluarocks.require "'..file..'" %*\n')
   wrapper:write("endlocal\n")
   wrapper:close()
   return true
end
