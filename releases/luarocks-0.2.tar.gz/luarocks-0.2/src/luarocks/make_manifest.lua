
--- Module implementing the luarocks-admin "make_manifest" command.
-- Compile a manifest file for a repository.
module("luarocks.make_manifest", package.seeall)

local fs = require("luarocks.fs")
local rep = require("luarocks.rep")
local search = require("luarocks.search")
local deps = require("luarocks.deps")
local config = require("luarocks.config")

help_summary = "Compile a manifest file for a repository."

help = [[
<argument>, if given, is a local repository pathname.
]]

local version_cache = {}
setmetatable(version_cache, {
   __mode = "kv"
})

--- Sort function for ordering rock identifiers in a manifest's
-- modules table.
-- @param a string: Version to compare.
-- @param b string: Version to compare.
-- @return boolean: True if a < b, false otherwise.
local function sort_pkgs(a, b)
   assert(type(a) == "string")
   assert(type(b) == "string")

   local va_s = a:match("/(.*)$")
   local vb_s = b:match("/(.*)$")
   local va = version_cache[va_s]
   local vb = version_cache[vb_s]
   if not va then
      va = deps.parse_version(va_s)
      version_cache[va_s] = va
   end
   if not vb then
      vb = deps.parse_version(vb_s)
      version_cache[vb_s] = vb
   end
   return va < vb
end

--- Output a table listing items of a package.
-- @param out userdata: a file handle opened for writing.
-- @param itemsfn function: a function for obtaining items of a package.
-- pkg and version will be passed to it; it should return a table with
-- items as keys.
-- @param pkg string: package name
-- @param tbl table: the package matching table: keys should be item names
-- and values arrays of strings with packages names in "name/version" format.
-- @param tblname string: the table name to be output.
local function write_and_store_package_items(out, itemsfn, pkg, version, tbl, tblname)
   local path = pkg.."/"..version
   out:write("\n"..tblname.."={")
   for item, _ in pairs(itemsfn(pkg, version)) do
      out:write("'"..item.."',")
      if not tbl[item] then
         tbl[item] = {}
      end
      table.insert(tbl[item], path)
   end
   out:write("},")
end

--- Output a table matching items to packages that provide them.
-- @param out userdata: a file handle opened for writing.
-- @param tbl table: the package matching table: keys should be strings
-- and values arrays of strings with packages names in "name/version" format.
-- @param tblname string: the table name to be output.
local function write_package_matching_table(out, tbl, tblname)
   assert(type(out) == "userdata")
   assert(type(tbl) == "table")
   assert(type(tblname) == "string")
   
   if next(tbl) then
      out:write("\n"..tblname.."={")
      for item, pkgs in pairs(tbl) do
         if #pkgs > 1 then
            table.sort(pkgs, sort_pkgs)
         end
         out:write('\n["'..item..'"]={')
         for _, pkg in ipairs(pkgs) do
            out:write('"'..pkg..'",')
         end
         out:write('},') 
      end
      out:write("}\n")
   end
end

--- Scan a LuaRocks repository and output a manifest file.
-- A file called 'manifest' will be written in the root of the given
-- repository directory.
-- @param repo A local repository directory.
-- @return boolean or (nil, string): True if manifest was generated,
-- or nil and an error message.
function make_manifest(repo)
   assert(type(repo) == "string")

   if not fs.is_dir(repo) then
      return nil, "Cannot access repository at "..repo
   end

   local query = search.make_query("")
   query.exact_name = false
   query.arch = "any"
   local results = {}
   search.disk_search(results, repo, query)

   out = io.open(fs.make_path(repo, "manifest"), "w")
   if not out then
      return nil, "Cannot create manifest file at "..repo
   end
   modules = {}
   commands = {}
   out:write("repository={")
   for pkg, versions in pairs(results) do
      out:write('\n\n["'..pkg..'"]={')
      for version, repos in pairs(versions) do
         out:write('["'..version..'"]={')
         for _, repo in ipairs(repos) do
            out:write("{arch='"..repo.arch.."',")
            if repo.arch == "installed" then
               write_and_store_package_items(out, rep.package_modules, pkg, version, modules, "modules")
               write_and_store_package_items(out, rep.package_commands, pkg, version, commands, "commands")
            end
            out:write("},")            
         end
         out:write("},\n")
      end
      out:write("},")
   end
   out:write("}\n")
   write_package_matching_table(out, modules, "modules")
   write_package_matching_table(out, commands, "commands")
   out:close()
   return true
end

--- Driver function for "make_manifest" command.
-- @param repo string or nil: Pathname of a local repository. If not given,
-- the default local repository configured as config.repo_dir is used.
-- @return boolean or (nil, string): True if manifest was generated,
-- or nil and an error message.
function run(repo)
   assert(type(repo) == "string" or not repo)
   repo = repo or config.repo_dir
   
   print("Making manifest for "..repo)
   
   return make_manifest(repo)
end
