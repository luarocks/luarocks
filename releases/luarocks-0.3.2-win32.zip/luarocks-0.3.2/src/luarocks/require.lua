
local global_env = _G
local plain_require = require
local plain_package_path = package.path
local plain_package_cpath = package.cpath
local package, assert, ipairs, pairs, os, print, table, type, next =
      package, assert, ipairs, pairs, os, print, table, type, next

--- Application interface with LuaRocks.
-- Load this module to LuaRocks-enable an application:
-- this overrides the require() function, making it able to
-- load modules installed as rocks.
module("luarocks.require")

local path = plain_require("luarocks.path")
local rep = plain_require("luarocks.rep")
local fetch = plain_require("luarocks.fetch")
local deps = plain_require("luarocks.deps")
local config = plain_require("luarocks.config")

context = nil
manifest = nil

--- Process the dependencies of a package to determine its dependency
-- chain for loading modules.
-- Recursively scan dependencies, to build a transitive closure of all
-- dependent packages.
-- @param name string: Package name.
-- @param version string: Package version.
-- @return boolean or (nil, string): True if succeeded, or nil and an
-- error message.
local function add_context(name, version)
   assert(type(name) == "string")
   assert(type(version) == "string")

   if context[name] then
      return true
   end
   local rockspec, err = fetch.load_rockspec(path.rockspec_file(name, version))
   if err then
      return nil, err
   end
   local matched, missing = deps.match_deps(rockspec)
   for _, match in pairs(matched) do
      add_context(match.name, match.version)
   end
   if next(missing) then
      local err = "Missing dependencies:\n"
      for _, dep in pairs(missing) do
         err = err .. "   " .. deps.show_dep(dep) .. "\n"
      end
      return nil, err
   end
   context[name] = version
   return true
end

--- Specify the root of LuaRocks' dependency chain.
-- In the presence of multiple versions of packages, it is necessary to,
-- at some point, indicate which dependency chain we're following.
-- set_context does this by allowing one to pick a package to be the
-- root of this dependency chain. Once a dependency chain is picked it's
-- easy to know which modules to load ("I want to use *this* version of
-- A, which requires *that* version of B, which requires etc etc etc").
-- @param name string: The package name of an installed rock.
-- @param version string or nil: Optionally, a version number
-- When a version is not given, it picks the highest version installed.
function set_context(name, version)
   assert(type(name) == "string")
   assert(type(version) == "string" or not version)

   context = {}

   if not version then
      local versions = rep.get_versions(name)
      local vtables = {}
      for _, version in ipairs(versions) do
         table.insert(vtables, deps.parse_version(version))
      end
      table.sort(vtables)
      version = vtables[#vtables].string
   end

   add_context(name, version)
   -- TODO: platform independence
   local lpath, cpath = "", ""
   for name, version in pairs(context) do
      lpath = lpath .. path.lua_dir(name, version) .. "/?.lua;"
      lpath = lpath .. path.lua_dir(name, version) .. "/?/init.lua;"
      cpath = cpath .. path.lib_dir(name, version) .."/?."..config.lib_extension..";"
   end
   global_env.package.path = lpath .. plain_package_path
   global_env.package.cpath = cpath .. plain_package_cpath
end


local function plain_require_on(name, version, module)
   local global_package = global_env.package
   local save_path = global_package.path
   local save_cpath = global_package.cpath
   global_package.path = path.lua_dir(name, version) .. "/?.lua;"
               .. path.lua_dir(name, version) .. "/?/init.lua;" .. save_path
   global_package.cpath = path.lib_dir(name, version) .. "/?."..config.lib_extension..";" .. save_cpath
   local result = plain_require(module)
   global_package.path = save_path
   global_package.cpath = save_cpath
   return result
end

--- Function that overloads require(), adding LuaRocks support.
-- This function wraps around Lua's standard require() call,
-- allowing it to find modules installed by LuaRocks.
-- A module is searched in installed rocks that match the
-- current LuaRocks context. If module is not part of the
-- context, or if a context has not yet been set, the module
-- in the package with the highest version is used.
-- If a module is not available in any installed rock, plain
-- require() is called, using the original package.path and
-- package.cpath lookup locations.
-- Additionally, version constraints for the matching rock may
-- be given as a second parameter. If version constraints could
-- not be fulfilled, this equates to the rock not being
-- available: as such, plain require() with the default paths
-- is called as a fallback.
-- @param module string: The module name, like in plain require().
-- @param constraints string: A comma-separated list of version
-- constraints.
-- @return table: The module table (typically), like in plain
-- require(). See <a href="http://www.lua.org/manual/5.1/manual.html#pdf-require">require()</a>
-- in the Lua reference manual for details.
function require(module, constraints)
   local loaded = package.loaded["module"]
   if loaded then
      return loaded
   end
   local providers = nil
   if not manifest then
      manifest = fetch.load_manifest(config.repo_dir)
   end
   if manifest then
      providers = manifest.modules[module]
   end
   if not providers then
      return plain_require(module)
   end
   if constraints then
      constraints = deps.parse_constraints(constraints)
   end
   if context then
      for _, provider in ipairs(providers) do
         local name, version = provider:match("^([^/]*)/(.*)$")
         if context[name] == version and
         ((not constraints) or (deps.match_constraints(deps.parse_version(version), constraints)))
         then
            return plain_require_on(name, version, module)
         end
      end
   else
      context = {}
   end
   local name, version
   for _, provider in ipairs(providers) do
      name, version = provider:match("^([^/]*)/(.*)$")
      if ((not constraints) or (deps.match_constraints(deps.parse_version(version), constraints)))
      then
         add_context(name, version)
         return plain_require_on(name, version, module)
      end
      name = nil
   end
   return plain_require(module)
end

global_env.require = require
